#include "Partida.h"
#include "InfoJoc.h"
#include "GraphicManager.h"
#include <fstream>
#include <iostream>

class Tetris
{
public:
	void Juga(int mode, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments);

private:
	Partida m_partida;
};