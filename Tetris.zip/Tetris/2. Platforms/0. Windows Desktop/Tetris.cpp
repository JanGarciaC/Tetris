#include "Tetris.h"


void Tetris::Juga(int mode, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments)
{

	m_partida.inicialitza(mode, const string & fitxerInicial, const string & fitxerFigures, const string & fitxerMoviments);

}