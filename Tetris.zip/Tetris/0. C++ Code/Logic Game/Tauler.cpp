#include "Tauler.h"
#include "InfoJoc.h"
#include "GraphicManager.h"
#include <iostream>

using namespace std;

Tauler::Tauler()        //constructor
{
    for (int i = 0; i < MAX_FILA; i++)
    {
        for (int j = 0; j < MAX_COL; j++)
            m_tauler[i][j] = 0;
    }
}
                            //Setters i Getters

void Tauler::modificarTauler(int columna, int fila, int valor)          //"set tauler"
{
    m_tauler[columna][fila] = valor;
}

int Tauler::llegirTauler(int columna, int fila)                         //"get tauler"
{
    return m_tauler[columna][fila];
}

            //procediments


int Tauler::eliminarFiles(Figura figura)
{
    afegirFigura(figura);                               //afegeixo figura al tauler
    int x, contador, files = 0;
    x = figura.getFila() -1;                            //"tradueixo" fila de la figura al tauler
    
    for (int i = 0; i < figura.getTamany(); i++)        //comprovo tantes files com tamany de la figura
    {
        contador = 0;
        for (int j = 0; j < MAX_COL; j++)
        {
            if (m_tauler[i+x][j] != 0)
                contador += 1;
        }
        
        if (contador == MAX_COL)
        {
            files += 1;
            contador = i+x;             //reutilitzo la variable contador --> guarda quantes files falten
            while(contador >= 0)
            {
                if(contador > 0)
                {
                    for(int k = 0; k < MAX_COL; k++)
                    {
                        m_tauler[contador][k] = m_tauler[contador-1][k];
                    }
                }
                else
                {
                    for(int k = 0; k < MAX_COL; k++)
                    {
                        m_tauler[0][k] = 0;
                    }
                }
                contador -= 1;
            }
        }
    }
    
    return files;
}

bool Tauler::comprovaTauler(Figura figura)
{
    bool valid = true;
    int x, y;       //coordenades al tauler
    
    for(int i = 0; i < figura.getTamany() && valid; i++)
    {
        for(int j = 0; j < figura.getTamany() && valid; j++)
        {
            x = figura.getColumna() + j - 1;
            y = figura.getFila() + i - 1;

            if ((figura.llegirMatriu(i, j) != 0 ) && ((m_tauler[y][x] != 0) || x < 0 || x >= MAX_COL || y >= MAX_FILA))
                valid = false;
        }
    }
    
    return valid;
}

void Tauler::afegirFigura(Figura figura)
{
    for (int i = 0; i < figura.getTamany(); i++)
    {
        for (int j = 0; j < figura.getTamany(); j++)
        {
            if (figura.llegirMatriu(i, j) != 0)
            {
                m_tauler[figura.getFila() + i - 1][figura.getColumna() + j - 1] = figura.llegirMatriu(i, j);
            }
        }
    }
}

void Tauler::dibuixa()
{
    for (int i = 0; i < MAX_FILA; i++)
    {
        for (int j = 0; j < MAX_COL; j++)
        {
            if (m_tauler[i][j] != 0)
                GraphicManager::getInstance()->drawSprite(IMAGE_NAME(m_tauler[i][j] + 1), MIDA_QUADRAT + POS_X_TAULER + (j * MIDA_QUADRAT), MIDA_QUADRAT + POS_Y_TAULER + ((i - 1) * MIDA_QUADRAT), false);
        }
    }
}
