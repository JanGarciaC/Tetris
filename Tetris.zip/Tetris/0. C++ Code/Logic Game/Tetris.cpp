#include "Tetris.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

#define SDL_MAIN_HANDLED
#include <windows.h>
#include "../Graphic Lib/libreria.h"
#include "../Graphic Lib/NFont/NFont.h"
#include <conio.h>      /* getch */ 

Tetris::Tetris(const string& fitxerPuntuacionsFacil, const string& fitxerPuntuacionsDificil)
{
    string nom;
    int punts;

    ifstream fitxer(fitxerPuntuacionsFacil);
    ifstream fitxer2(fitxerPuntuacionsDificil);

    for(int i = 0; i < 5; i++)
    {
        fitxer >> nom >> punts;
        m_nomsFacil.push_back(string(nom));
        m_puntsFacil.push_back(int(punts));
        fitxer2 >> nom >> punts;
        m_nomsDificil.push_back(string(nom));
        m_puntsDificil.push_back(int(punts));
    }

    fitxer.close();
    fitxer2.close();
}

void Tetris::actualitzarFitxer(const string& fitxerPuntuacionsFacil, const string& fitxerPuntuacionsDificil)
{
    ofstream fitxer(fitxerPuntuacionsFacil);
    ofstream fitxer2(fitxerPuntuacionsDificil);

    itPuntsFacil = m_puntsFacil.begin();
    itNomsFacil = m_nomsFacil.begin();
    itPuntsDificil = m_puntsDificil.begin();
    itNomsDificil = m_nomsDificil.begin();

    while (itPuntsFacil != m_puntsFacil.end())
    {
        fitxer << *itNomsFacil << " " << *itPuntsFacil << endl;
        fitxer2 << *itNomsDificil << " " << *itPuntsDificil << endl;
        itPuntsFacil++;
        itNomsFacil++;
        itPuntsDificil++;
        itNomsDificil++;
    }

    fitxer.close();
}

void Tetris::Juga(int mode, int dificultat, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments,Screen& pant)
{
    bool sortir = false;
    bool condicio = false;
    int punts;
    string nom;

	Uint64 NOW = SDL_GetPerformanceCounter();
	Uint64 LAST = 0;
	double deltaTime = 0;

	m_partida.inicialitza(mode, fitxerInicial, fitxerFigures, fitxerMoviments);
    m_partida.setDificultat(dificultat);

    do
    {
        LAST = NOW;
        NOW = SDL_GetPerformanceCounter();
        deltaTime = (double)((NOW - LAST) / (double)SDL_GetPerformanceFrequency());

        // Captura tots els events de ratol� i teclat de l'ultim cicle
        pant.processEvents();

        sortir = m_partida.actualitza(mode, deltaTime);

        // Actualitza la pantalla
        pant.update();

    } while (!Keyboard_GetKeyTrg(KEYBOARD_ESCAPE) && !sortir);

    if (mode == 0)
    {
        punts = m_partida.getPunts();

        system("cls");

        cout << "FI DE LA PARTIDA" << endl << "=======================" << endl << "Punts: " << punts << endl << "Introdueix el teu nom per actualitzar puntuacions : ";

        cin >> nom;

        if (dificultat == 1)
        {
            itPuntsFacil = m_puntsFacil.begin();
            itNomsFacil = m_nomsFacil.begin();

            while (itPuntsFacil != m_puntsFacil.end() && !condicio)
            {
                if (*itPuntsFacil < punts)
                {
                    m_puntsFacil.insert(itPuntsFacil, punts);
                    m_nomsFacil.insert(itNomsFacil, nom);
                    itPuntsFacil = m_puntsFacil.begin();
                    itNomsFacil = m_nomsFacil.begin();
                    m_puntsFacil.pop_back();
                    m_nomsFacil.pop_back();
                    condicio = true;
                }
                else
                {
                    itPuntsFacil++;
                    itNomsFacil++;
                }
            }
        }
        else
        {
            itPuntsDificil = m_puntsDificil.begin();
            itNomsDificil = m_nomsDificil.begin();

            while (itPuntsDificil != m_puntsDificil.end() && !condicio)
            {
                if (*itPuntsDificil < punts)
                {
                    m_puntsDificil.insert(itPuntsDificil, punts);
                    m_nomsDificil.insert(itNomsDificil, nom);
                    itPuntsDificil = m_puntsDificil.begin();
                    itNomsDificil = m_nomsDificil.begin();
                    m_puntsDificil.pop_back();
                    m_nomsDificil.pop_back();
                    condicio = true;
                }
                else
                {
                    itPuntsDificil++;
                    itNomsDificil++;
                }
            }
        }

    }

}

void Tetris::mostraPuntuacions(int dificultat)
{
    system("cls");
    if (dificultat == 1)
    {
        itPuntsFacil = m_puntsFacil.begin();
        itNomsFacil = m_nomsFacil.begin();

        cout << "Llista de puntuacions Facil: " << endl << "=======================" << endl;

        while (itPuntsFacil != m_puntsFacil.end())
        {
            cout << "Nom: " << *itNomsFacil << " ||| Punts: " << *itPuntsFacil << endl;
            itPuntsFacil++;
            itNomsFacil++;
        }
    }
    else
    {
        if (dificultat == 2)
        {
            itPuntsDificil = m_puntsDificil.begin();
            itNomsDificil = m_nomsDificil.begin();

            cout << "Llista de puntuacions Dificil: " << endl << "=======================" << endl;

            while (itPuntsDificil != m_puntsDificil.end())
            {
                cout << "Nom: " << *itNomsDificil << " ||| Punts: " << *itPuntsDificil << endl;
                itPuntsDificil++;
                itNomsDificil++;
            }
        }
        else
        {
            cout << "===== NIVELL DE DIFICULTAT NO VALID =====" << endl;
        }
    }
}
