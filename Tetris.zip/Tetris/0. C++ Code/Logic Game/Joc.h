#ifndef JOC_H
#define JOC_H
#include "Tauler.h"
#include "Figura.h"
#include "GraphicManager.h"
#include "InfoJoc.h"
#include <string>
using namespace std;

class Joc
{
public:
	Joc();
	void inicialitza(const string& nomFitxer);
	bool giraFigura(DireccioGir direccio);
	bool mouFigura(int dirX);
	int baixaFigura();
	void escriuTauler(const string& nomFitxer);
	void dibuixa(int dificultat);
	int baixaFiguraTotal();
	bool novaFigura(int mode, Figura seguentFig);
	void reinicia();
	bool detectarFinal();

private:
    Tauler m_tauler;
    Figura m_figura;
	int llistaFigures[8][2];
	int figuraActual;
};

#endif