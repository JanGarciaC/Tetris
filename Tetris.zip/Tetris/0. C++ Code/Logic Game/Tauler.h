#ifndef TAULER_H
#define TAULER_H
#include "Figura.h"
#include "GraphicManager.h"
#include "InfoJoc.h"

const int MAX_FILA = N_FILES_TAULER;
const int MAX_COL = N_COL_TAULER;

class Tauler
{
public:
    Tauler();
    ~Tauler() {}
    
    bool comprovaTauler(Figura figura);                         //comprova si una posicio es valida
    void afegirFigura(Figura figura);                           //colocar la figura al tauler
    void modificarTauler(int columna, int fila, int valor);     //modificar una casella del tauler
    int llegirTauler(int columna, int fila);                    //llegir una casella del tauler
    int eliminarFiles(Figura figura);                           //elimina una fila
    void dibuixa();
    
    
private:
    int m_tauler[N_FILES_TAULER][N_COL_TAULER];
    
    
};
#endif