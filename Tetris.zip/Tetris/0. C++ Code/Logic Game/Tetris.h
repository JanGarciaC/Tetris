#include "Partida.h"
#include "InfoJoc.h"
#include "GraphicManager.h"
#include <fstream>
#include <iostream>
#include <list>

class Tetris
{
public:
	Tetris(const string& fitxerPuntuacionsFacil, const string& fitxerPuntuacionsDificil);
	void Juga(int mode, int dificultat, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments, Screen& pantalla);
	void mostraPuntuacions(int dificultat);
	void actualitzarFitxer(const string& fitxerPuntuacionsFacil, const string& fitxerPuntuacionsDificil);

private:
	Partida m_partida;
	std::list<int> m_puntsFacil;
	std::list<int>::iterator itPuntsFacil;
	std::list<string> m_nomsFacil;
	std::list<string>::iterator itNomsFacil;
	std::list<int> m_puntsDificil;
	std::list<int>::iterator itPuntsDificil;
	std::list<string> m_nomsDificil;
	std::list<string>::iterator itNomsDificil;
};