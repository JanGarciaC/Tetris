#include "Figura.h"
#include "InfoJoc.h"
#include "GraphicManager.h"
#include <iostream>

using namespace std;

        // Declaracio dels constructors i destructors
        
Figura::~Figura()
{
    
}
    
Figura::Figura()
{
    m_tipus = 0;
    m_fila = 0;
    m_columna = 0;
    m_tamany = 0;
    m_gir = 0;
    for (int i = 0; i < MAX_AMPLADA; i++)
    {
        for (int j = 0; j < MAX_ALCADA; j++)
            m_matriu[i][j] = 0;
    }
}

Figura::Figura(int tipus, int fila, int columna, int gir)
{
    m_tipus = tipus;
    m_fila = fila;
    m_columna = columna;
    m_gir = gir;
    if (m_tipus == 1)
        m_tamany = 2;
    else
    {
        if (m_tipus == 2)
            m_tamany = 4;
        else
            m_tamany = 3;
    }
    
    inicialitzaMatriu();
}

void Figura::inicialitzaMatriu()
{
    for (int i = 0; i < MAX_AMPLADA; i++)
    {
        for (int j = 0; j < MAX_ALCADA; j++)
            m_matriu[i][j] = 0;
    }
    switch (m_tipus) 
        {
        case 1:
            m_matriu[0][0] = m_tipus;
            m_matriu[0][1] = m_tipus;
            m_matriu[1][0] = m_tipus;
            m_matriu[1][1] = m_tipus;
            break;
        case 2:
            m_matriu[0][1] = m_tipus;
            m_matriu[1][1] = m_tipus;
            m_matriu[2][1] = m_tipus;
            m_matriu[3][1] = m_tipus;
            break;
        case 3:
            m_matriu[1][0] = m_tipus;
            m_matriu[0][1] = m_tipus;
            m_matriu[1][1] = m_tipus;
            m_matriu[2][1] = m_tipus;
            break;
        case 4:
            m_matriu[2][0] = m_tipus;
            m_matriu[0][1] = m_tipus;
            m_matriu[1][1] = m_tipus;
            m_matriu[2][1] = m_tipus;
            break;
        case 5:
            m_matriu[0][0] = m_tipus;
            m_matriu[0][1] = m_tipus;
            m_matriu[1][1] = m_tipus;
            m_matriu[2][1] = m_tipus;
            break;
        case 6:
            m_matriu[0][0] = m_tipus;
            m_matriu[1][0] = m_tipus;
            m_matriu[1][1] = m_tipus;
            m_matriu[2][1] = m_tipus;
            break;
        case 7:
            m_matriu[1][0] = m_tipus;
            m_matriu[2][0] = m_tipus;
            m_matriu[0][1] = m_tipus;
            m_matriu[1][1] = m_tipus;
            break;
        }

    int rotacio = m_gir;
    m_gir = 0;

    for (int i = 0; i < rotacio; i++)
       gir(GIR_HORARI);
}

        // Declaracio de tots els getters
        
int Figura::llegirMatriu(int columna, int fila)
{
    return m_matriu[columna][fila];
}

int Figura::getGir()
{
    return m_gir;
}
    
int Figura::getTipus()
{
    return m_tipus;
}

int Figura::getFila()
{
    return m_fila;
}

int Figura::getColumna()
{
    return m_columna;
}

int Figura::getTamany()
{
    return m_tamany;
}

        // Declaracio de tots els setters

void Figura::setTipus(int tipus)        // aquest setter dona un valor al tipus i tamany simultaneament
{
    m_tipus = tipus;
    if (m_tipus == 1)
        m_tamany = 2;
    else
    {
        if (m_tipus == 2)
            m_tamany = 4;
        else
            m_tamany = 3;
    }

    inicialitzaMatriu();
}

void Figura::setGir(int gir)
{
    m_gir = gir;
}

void Figura::setFila(int fila)
{
    m_fila = fila;
}

void Figura::setColumna(int columna)
{
    m_columna = columna;
}

        // Declaracio dels procediments

void Figura::gir(DireccioGir dir)
{
    int auxiliar;
    
    for (int i = 0; i < m_tamany; i++)
    {
        for (int j = 0; j < m_tamany; j++)
            {
                if (j > i)                                      //trasposo
                {
                    auxiliar = m_matriu[j][i];
                    m_matriu[j][i] = m_matriu[i][j];
                    m_matriu[i][j] = auxiliar;
                }
            }
    }
    
    if (dir == GIR_HORARI)       //gir horari o antihorari
    {
        if (m_gir < 3)
            m_gir++;
        else
            m_gir = 0;

        for (int i = 0; i < (m_tamany/2); i++)
        {
            for (int j = 0; j < m_tamany; j++)                  //invertir columnes
            {
                auxiliar = m_matriu[i][j];
                m_matriu[i][j] = m_matriu[m_tamany - i - 1][j];
                m_matriu[m_tamany- i - 1][j] = auxiliar;
            }
        }
    }
    else
    {
        if (m_gir > 0)
            m_gir--;
        else
            m_gir = 3;
        for (int i = 0; i < m_tamany/2; i++)
        {
            for (int j = 0; j < m_tamany; j++)                  //invertir files
            {
                auxiliar = m_matriu[j][i];
                m_matriu[j][i] = m_matriu[j][m_tamany - i - 1];
                m_matriu[j][m_tamany- i - 1] = auxiliar;
            }

        }

    }
    
}

void Figura::mouDreta()
{
    m_columna += 1;
}

void Figura::mouEsquerra()
{
    m_columna -= 1;
}

void Figura::baixarFigura()
{
    m_fila += 1;
}

void Figura::pujarFigura()
{
    m_fila -= 1;
}

void Figura::eliminarMatriu()
{
    for (int i = 0; i < m_tamany; i++)
    {
        for (int j = 0; j < m_tamany; j++)
        {
            m_matriu[i][j] = 0;
        }
    }
    m_gir = 0;
}

void Figura::dibuixa(int color, bool seguent)
{
    if (!seguent)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (m_matriu[i][j] != 0)
                {
                    GraphicManager::getInstance()->drawSprite(IMAGE_NAME(color), POS_X_TAULER + ((j + m_columna) * MIDA_QUADRAT), POS_Y_TAULER +  ((i - 1 + m_fila)* MIDA_QUADRAT), false);
                }
            }
        }
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (m_matriu[i][j] != 0)
                {
                    GraphicManager::getInstance()->drawSprite(IMAGE_NAME(color), POS_X_TAULER + ((j + 14) * MIDA_QUADRAT), POS_Y_TAULER + (i * MIDA_QUADRAT), false);
                }
            }
        }
    }
}


