//
//  main.cpp
//
//  Copyright � 2018 Compiled Creations Limited. All rights reserved.
//

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__) || defined  (_WIN64)

#include <iostream>
//Definicio necesaria per poder incloure la llibreria i que trobi el main
#define SDL_MAIN_HANDLED
#include <windows.h>
//Llibreria grafica
#include "../Graphic Lib/libreria.h"
#include "../Graphic Lib/NFont/NFont.h"
#include <conio.h>      /* getch */ 

#elif __APPLE__
//Llibreria grafica
#include "../Graphic Lib/libreria.h"
#include "../Graphic Lib/NFont/NFont.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdocumentation"
#include <SDL2/SDL.h>
#pragma clang diagnostic pop

#endif

#include "./Partida.h"
#include "./InfoJoc.h"
#include "Tetris.h"
#include <stdlib.h> 


int main(int argc, const char* argv[])
{
    int seleccionarMode, seleccionarDificultat;
    bool finalPrograma = false;
    srand(time(NULL));

    //Instruccions necesaries per poder incloure la llibreria i que trobi el main
    SDL_SetMainReady();
    SDL_Init(SDL_INIT_VIDEO);

    Screen pantalla(SCREEN_SIZE_X, SCREEN_SIZE_Y);
    pantalla.show();

    Tetris tetris("./data/games/puntsFacil.txt", "./data/games/puntsDificil.txt");

    while(!finalPrograma)
    { 
        cout << "1 -- > Mode Normal" << endl;
        cout << "2 -- > Mode Test" << endl;
        cout << "3 -- > Llista Punts" << endl;
        cout << "4 -- > Sortir" << endl;

        cin >> seleccionarMode;        

        system("cls");

        switch (seleccionarMode)
        {
        case 1:
            cout << "Introdueix el nivell de dificultat: " << endl << "1. Facil: Amb ajuda i velocitat lenta." << endl << "2. Dificil: sense ajuda i velocitat rapida." << endl;
            cin >> seleccionarDificultat;
            system("cls");
            if (seleccionarDificultat == 1 || seleccionarDificultat == 2)
            {
                cout << "Ja pots jugar, obre la pestanya grafica" << endl;
                tetris.Juga(0, seleccionarDificultat, "./data/games/partida.txt", "./data/games/figures.txt", "./data/games/moviments.txt", pantalla);
            }
            else
                cout << "===== NIVELL DE DIFICULTAT NO VALID =====" << endl;
            break;
        case 2:
            tetris.Juga(1, 0, "./data/games/partida.txt", "./data/games/figures.txt", "./data/games/moviments.txt", pantalla);
            break;
        case 3:
            cout << "Introdueix el nivell de dificultat: (1 facil, 2 dificil)" << endl;
            cin >> seleccionarDificultat;
            tetris.mostraPuntuacions(seleccionarDificultat);
            break;
        case 4:
            finalPrograma = true;
            tetris.actualitzarFitxer("./data/games/puntsFacil.txt", "./data/games/puntsDificil.txt");
            break;
        default:
            cout << "Opcio no valida, insereix un altre valor" << endl;
            break;
        }
    }

    SDL_Quit();
    return 0;
}

