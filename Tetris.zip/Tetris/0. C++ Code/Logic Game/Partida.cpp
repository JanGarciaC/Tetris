#include "Partida.h"
#include "InfoJoc.h"
#include "GraphicManager.h"
#include <fstream>
#include <iostream>

using namespace std;

Partida::Partida()
{
    m_temps = 0;
    punts = 0;
    nivell = 0;
}

int Partida::getPunts()
{
    return punts;
}

void Partida::setDificultat(int dif)
{
    dificultat = dif;
}

void Partida::inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures,const string& fitxerMoviments)
{
    bool novaFigura;
    punts = 0;
    nivell = 0;
    m_temps = 0;


    if (mode == 1)
    {
        m_joc.inicialitza(fitxerInicial);

        ifstream fitxer(fitxerMoviments);

        int moviment = 0;

        while (!fitxer.eof())
        {
            fitxer >> moviment; 
            movs.insereixNode(moviment);
        }

        fitxer.close();

        ifstream fitxer2(fitxerFigures);

        int tipus, fila, columna, gir;
        
        while (!fitxer2.eof())
        {
            fitxer2 >> tipus >> fila >> columna >> gir;
            Figura aux(tipus, fila, columna, gir);
            figs.insereixFigura(aux);
        }

        fitxer2.close();

    }
    else
    {
        m_joc.reinicia();
    }
}

bool Partida::actualitza(int mode, double deltaTime)
{
    int files = 0;
    bool novaFigura = false;
    bool sortir = false;

    m_temps += deltaTime;

    GraphicManager::getInstance()->drawSprite(GRAFIC_FONS, 0, 0, false);
    GraphicManager::getInstance()->drawSprite(GRAFIC_TAULER, POS_X_TAULER, POS_Y_TAULER, false);

    if (mode == 0)
    {
        if (dificultat == 1)
        {
            if ((m_temps > 1.2 - float(nivell / 20) && nivell <= 20) || (m_temps > 0.2 && nivell >= 20))
            {
                files = m_joc.baixaFigura();
                m_temps = 0;
            }
        }
        else
        {
            if ((m_temps > 0.5 - float(nivell / 20) && nivell <= 8) || (m_temps > 0.1 && nivell >= 8))
            {
                files = m_joc.baixaFigura();
                m_temps = 0;
            }
        }

        if (Keyboard_GetKeyTrg(KEYBOARD_RIGHT))
            m_joc.mouFigura(1);
        if (Keyboard_GetKeyTrg(KEYBOARD_LEFT))
            m_joc.mouFigura(0);
        if (Keyboard_GetKeyTrg(KEYBOARD_UP))
            m_joc.giraFigura(GIR_HORARI);
        if (Keyboard_GetKeyTrg(KEYBOARD_DOWN))
            m_joc.giraFigura(GIR_ANTI_HORARI);
        if (Keyboard_GetKeyTrg(KEYBOARD_SPACE))
            files = m_joc.baixaFiguraTotal();

        Figura figura;
        novaFigura = m_joc.novaFigura(0, figura);

        if (novaFigura)
        {
            punts += 10;
        }

        m_joc.dibuixa(dificultat);

    }
    else
    {
        if (m_temps >= 0.5)
        {
            m_temps = 0;

            int condd;

            condd = movs.getMoviment();

            if (condd != -1)
            {
                switch (TipusMoviment(movs.getMoviment()))
                {
                case MOVIMENT_ESQUERRA:
                    m_joc.mouFigura(0);
                    break;

                case MOVIMENT_DRETA:
                    m_joc.mouFigura(1);
                    break;

                case MOVIMENT_GIR_HORARI:
                    m_joc.giraFigura(GIR_HORARI);
                    break;

                case MOVIMENT_GIR_ANTI_HORARI:
                    m_joc.giraFigura(GIR_ANTI_HORARI);
                    break;

                case MOVIMENT_BAIXA:
                    files = m_joc.baixaFigura();

                case MOVIMENT_BAIXA_FINAL:
                    files = m_joc.baixaFiguraTotal();
                }

            }
            else
            {
                sortir = true;
            }
        }

        aux = figs.getFigura();

        if (aux.getTipus() != -1)
        {
            novaFigura = m_joc.novaFigura(1, aux);
        }
        else
            sortir = true;

        if (novaFigura)
        {
            punts += 10;
            figs.incHead();
        }

        m_joc.dibuixa(1);
    }

    switch (files)
    {
    case 1:
        punts += 100;
        break;

    case 2:
        punts += 250;
        break;

    case 3:
        punts += 375;
        break;

    case 4:
        punts += 500;
        break;

    default:
        break;
    }

    files = 0;
    nivell = round(punts / 1000);

    string msg = "Punts: " + to_string(punts) + ", Nivell: " + to_string(int(nivell));
    GraphicManager::getInstance()->drawFont(FONT_WHITE_30, POS_X_TAULER, POS_Y_TAULER - 50, 1.0, msg);

    if (sortir == false)
    {
        sortir = m_joc.detectarFinal();
    }

    return sortir;

}

