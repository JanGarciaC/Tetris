#include "Joc.h"
#include <fstream>
#include <iostream>

using namespace std;

Joc::Joc()
{
    figuraActual = 0;
    m_figura.setFila(rand() % 1 + 1);
    m_figura.setColumna(rand() % 2 + 5);
    m_figura.setGir(rand() % 4);

    for (int i = 0; i < 7; i++)
    {
        llistaFigures[i][0] = i + 1;
        llistaFigures[i][1] = rand() % 4;
    }

    llistaFigures[7][0] = rand() % 7;
    llistaFigures[7][1] = rand() % 4;

    for (int i = 0; i < 7; i++)
    {
        bool prova;
        int n;
        do
        {
            n = rand() % 7;
            prova = true;
            for (int j = 1; j < i; j++)
                if (n == llistaFigures[j][0])
                {
                    prova = false;
                    break;
                }
        } while (!prova);
        llistaFigures[i][0] = n;
    }
}

void Joc::inicialitza(const string& nomFitxer)
{
    ifstream fitxer(nomFitxer);

    figuraActual = 10;
    
    int tipus = 0, fila = 0, columna = 0, rotacio = 0, valor = 0;
    
    fitxer >> tipus >> fila >> columna >> rotacio;      //obtenir propietats de la figura
    
    m_figura.setGir(rotacio);
    m_figura.setTipus(tipus);
    m_figura.setFila(fila);
    m_figura.setColumna(columna);
    m_figura.inicialitzaMatriu();
    
    for (int i = 0; i < N_FILES_TAULER; i++)                  //llegir tot el tauler
    {
        for (int j = 0; j < N_COL_TAULER; j++)
        {
            fitxer >> valor;
            m_tauler.modificarTauler(i, j, valor);
        }
    }
    
    fitxer.close();
}

void Joc::escriuTauler(const string& nomFitxer)
{
    ofstream fitxer(nomFitxer);
    int valor;
    
    m_tauler.afegirFigura(m_figura);
    
    for (int i = 0; i < MAX_FILA; i++)                  //escriure tot el tauler
    {
        for (int j = 0; j < MAX_COL; j++)
        {
            valor = m_tauler.llegirTauler(j, i);
            fitxer << valor << " ";
        }
        fitxer << endl;
    }
    
    
    fitxer.close();
}

bool Joc::mouFigura(int dirX)
{
    bool possible = true;
    
    if (dirX == 1)
    {
        m_figura.mouDreta();
        possible = m_tauler.comprovaTauler(m_figura);
        if (!possible)
            m_figura.mouEsquerra();
    }
    else
    {
        m_figura.mouEsquerra();
        possible = m_tauler.comprovaTauler(m_figura);
        if (!possible)
            m_figura.mouDreta();
    }
    
    return possible;
}


int Joc::baixaFigura() 
{
    int files = 0;
    
    m_figura.baixarFigura();
    
    if (!m_tauler.comprovaTauler(m_figura))
    {
        m_figura.pujarFigura();
        files = m_tauler.eliminarFiles(m_figura);
        m_figura.eliminarMatriu();
    }
    
    return files;
}

bool Joc::giraFigura(DireccioGir direccio)
{
    bool possible = true;
    m_figura.gir(direccio);         //començo rotant la figura i despres provo si es valid
    
    possible = m_tauler.comprovaTauler(m_figura);
    
    if (!possible && direccio == GIR_ANTI_HORARI)
    {
        m_figura.gir(GIR_HORARI);
    }
    if (!possible && direccio == GIR_HORARI)
    {
        m_figura.gir(GIR_ANTI_HORARI);
    }
    
    return possible;
}

int Joc::baixaFiguraTotal()
{
    int files = 0;
    bool possible = true;
    
    while (m_tauler.comprovaTauler(m_figura))
    {
        m_figura.baixarFigura();
    }

    m_figura.pujarFigura();
    files = m_tauler.eliminarFiles(m_figura);
    m_figura.eliminarMatriu();

    return files;
}

void Joc::dibuixa(int dificultat)
{

    if (dificultat == 1)
    {
        Figura figuraAux(m_figura.getTipus(), m_figura.getFila(), m_figura.getColumna(), m_figura.getGir());

        while (m_tauler.comprovaTauler(figuraAux))
        {
            figuraAux.baixarFigura();
        }

        figuraAux.pujarFigura();

        figuraAux.dibuixa(9, false);
    }
    Figura figuraSeg(llistaFigures[figuraActual][0] + 1, 0, 0, llistaFigures[figuraActual][1]);
    m_tauler.dibuixa();
    m_figura.dibuixa(m_figura.getTipus() + 1, false);
    figuraSeg.dibuixa(llistaFigures[figuraActual][0] + 2, true);
}

bool Joc::novaFigura(int mode, Figura seguentFig)
{
    
    int valor;

    bool possible = true;

    for (int i = 0; i < 4 && possible; i++)
    {
        for (int j = 0; j < 4 && possible; j++)
        {
            if (m_figura.llegirMatriu(i, j) != 0)
                possible = false;
        }
    }

    if (mode == 0)
    {

        if (possible)
        {
            m_figura.setFila(1);
            m_figura.setColumna(5);
            if (figuraActual >= 7)
            {
                figuraActual = 0;

                for (int i = 1; i < 7; i++)
                {
                    llistaFigures[i][0] = i + 1;
                    llistaFigures[i][1] = rand() % 4;
                }

                llistaFigures[0][0] = llistaFigures[7][0];
                llistaFigures[0][1] = llistaFigures[7][1];
                llistaFigures[7][0] = rand() % 7;
                llistaFigures[7][1] = rand() % 4;

                for (int i = 1; i < 8; i++)
                {
                    bool prova;
                    int n;
                    do
                    {
                        n = rand() % 7;
                        prova = true;
                        for (int j = 1; j < i; j++)
                            if (n == llistaFigures[j][0])
                            {
                                prova = false;
                                break;
                            }
                    } while (!prova);
                    llistaFigures[i][0] = n;
                }
            }

            m_figura.setGir(0);
            m_figura.setTipus(llistaFigures[figuraActual][0] + 1);

            for (int i = 0; i < llistaFigures[figuraActual][1]; i++)
            {
                m_figura.gir(GIR_HORARI);
            }
            figuraActual++;

        }

    }
    else
    {
        if (possible)
        {
            m_figura.setGir(seguentFig.getGir());
            m_figura.setTipus(seguentFig.getTipus());
            m_figura.setFila(seguentFig.getFila());
            m_figura.setColumna(seguentFig.getColumna());
        }
    }
    
    return possible;
}

bool Joc::detectarFinal()
{
    bool final = false;

    for (int i = 0; i < MAX_COL; i++)
    {
        if (m_tauler.llegirTauler(0, i) != 0)
            final = true;
    }

    return final;
}

void Joc::reinicia()
{
    m_figura.eliminarMatriu();
    Figura figura;
    this->novaFigura(0, figura);
    for (int i = 0; i < N_COL_TAULER; i++)
    {
        for (int j = 0; j < N_FILES_TAULER; j++)
            m_tauler.modificarTauler(j, i, 0);
    }
}