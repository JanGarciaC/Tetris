#include <iostream>
#include "figura.h"

typedef enum
{
    MOVIMENT_ESQUERRA = 0,
    MOVIMENT_DRETA,
    MOVIMENT_GIR_HORARI,
    MOVIMENT_GIR_ANTI_HORARI,
    MOVIMENT_BAIXA,
    MOVIMENT_BAIXA_FINAL,
} TipusMoviment;

class NodeMov
{
public:
    NodeMov() { moviment = MOVIMENT_BAIXA; next = NULL; }
    NodeMov(int mov) { moviment = TipusMoviment(mov); next = NULL; }

    TipusMoviment moviment;
    NodeMov* next;
};

class NodeFig
{
public:
    NodeFig() { next = NULL; }
    NodeFig(int gir, int tipus, int fila, int columna) { figura.setGir(gir); figura.setTipus(tipus); figura.setFila(fila); figura.setColumna(columna); next = NULL;  }

    Figura figura;
    NodeFig* next;
};

class llistaMov 
{
private:
    NodeMov* head;
    NodeMov* aux;

public:
    llistaMov() { head = NULL; aux = NULL; }

    void insereixNode(int posicio);
    int getMoviment();
};

class llistaFig
{
private:
    NodeFig* head;

public:
    llistaFig() { head = NULL; }

    void incHead();
    void insereixFigura(Figura figura);
    Figura getFigura();
};
