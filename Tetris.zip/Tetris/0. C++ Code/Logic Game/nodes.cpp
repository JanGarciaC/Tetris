#include "nodes.h"

void llistaMov::insereixNode(int data)
{
    // Crear nou node
    NodeMov* newNode = new NodeMov(data);

    // Assignar al head 
    if (head == NULL) {
        head = newNode;
        return;
    }

    // Buscar el final
    NodeMov* temp = head;
    while (temp->next != NULL) {

        // actualitzar temp 
        temp = temp->next;
    }

    // Inserir al final 
    temp->next = newNode;
}

int llistaMov::getMoviment()
{
    int movi = -1;
    if (aux == NULL)
        aux = head;

    if (aux != NULL)
    {
        movi = aux->moviment;
        aux = aux->next;
    }

    return movi;
}

void llistaFig::insereixFigura(Figura figura)
{
    // Crear nou node
    NodeFig* newNode = new NodeFig(figura.getGir(), figura.getTipus(), figura.getFila(), figura.getColumna());

    // Assignar al head 
    if (head == NULL) {
        head = newNode;
        return;
    }

    // Buscar el final
    NodeFig* temp = head;
    while (temp->next != NULL) {

        // actualitzar temp 
        temp = temp->next;
    }

    // Inserir al final 
    temp->next = newNode;
}

Figura llistaFig::getFigura()
{
    Figura fig;
    fig.setTipus(-1);
    
    if (head != NULL)
    {
        fig = head->figura;
    }

    return fig;
}

void llistaFig::incHead()
{
    head = head->next;
}