#ifndef PARTIDA_H
#define PARTIDA_H

#include <stdio.h>
#include <string>
#include "InfoJoc.h"
#include "Figura.h"
#include "Joc.h"
#include "Tauler.h"
#include "nodes.h"
#include <iostream>
#include <list>

using namespace std;


class Partida 
{
public:
    Partida();
    bool actualitza(int mode, double deltaTime);
    void inicialitza(int mode, const string& fitxerInicial, const string& fitxerFigures, const string& fitxerMoviments);
    int getPunts();
    void setDificultat(int dificultat);

private:
    double m_temps;
    Joc m_joc;
    int punts;
    float nivell;  
    int dificultat;
    llistaMov movs;
    llistaFig figs;
    Figura aux;
};




#endif 
