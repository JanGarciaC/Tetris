#ifndef FIGURA_H
#define FIGURA_H

const int MAX_ALCADA = 4;
const int MAX_AMPLADA = 4;

typedef enum
{
    GIR_HORARI = 0,
    GIR_ANTI_HORARI
} DireccioGir;

class Figura
{
public:
                //constructors i destructor

    Figura();       
    Figura(int tipus, int fila, int columna, int gir);       
    ~Figura();
    
                //getters i setters
    
    int getTipus();                             //obtenir un tipus de figura
    int getFila();                              //obtenir fila actual
    int getColumna();                           //obtenir columna actua
    int getTamany();                            //obtenir el tamany
    int getGir();
    void setGir(int gir);
    void setTipus(int tipus);                   //defineix un tipus de figura
    void setFila(int fila);                     //defineix fila actual
    void setColumna(int columna);               //defineix columna actual
    int llegirMatriu(int columna, int fila);    //retorna una posicio de la matriu
    void eliminarMatriu();                      //posa tota la matriu a zero --> eliminar en el futur
    
                //procediments
    
    void gir(DireccioGir dir);       //rotar figura
    void mouDreta();               //moure figura a la dreta
    void mouEsquerra();            //moure figura a la esquerra
    void baixarFigura();             //moure figura cap abaix
    void pujarFigura();              //moure figura cap a dalt
    void inicialitzaMatriu();    //crea la matriu corresponent a cada figura i li otorga la rotacio corresponent
    void dibuixa(int color, bool seguent);

private:
    int m_tipus;                            //guarda simultaniament forma i color    
    int m_fila;                             //guarda fila actual                     
    int m_columna;                          //guarda columna actual                  
    int m_matriu[MAX_AMPLADA][MAX_ALCADA];  //Matriu que guarda l'estat actual de la figura
    int m_tamany;                           //guarda el tamany maxim de la figura (2 per el cub, 3 per les generals i 4 per la i)
    int m_gir;
     
    
};


#endif
